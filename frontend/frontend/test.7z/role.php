<?php

session_start();
$token = $_SESSION['token'];

$url = "http://localhost:8080/api/users/getroles/?userId=".$_SESSION['id'];
$curl = curl_init();

$data = array(
    'userId' => $_SESSION['id']
);
$jsonData = json_encode($data);



curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',  
    'Authorization: Bearer ' . $token  
));

curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData);

$response = curl_exec($curl);
var_dump($response);
if (curl_errno($curl)) {
    echo 'Błąd: ' . curl_error($curl);
}

curl_close($curl);
$responseData = json_decode($response, true);


if($responseData == NULL){
    echo "Brak dostępu";
    cofnij();
}
else{
    var_dump($responseData);
    cofnij();
}



function cofnij(){
    $site = "
    <br><a href='logowanie.php'><button>cofnij</button></a>
    ";
    echo $site;
}
